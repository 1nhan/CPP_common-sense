This is a Qt version of https://github.com/BjarneStroustrup/Programming-_Principles_and_Practice_Using_Cpp
